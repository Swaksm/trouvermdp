import csv
import hashlib

def load_rainbow_table(filename):
    rainbow_table = {}
    with open(filename, 'r') as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            reduced, password = row
            rainbow_table[reduced] = password
    return rainbow_table

def find_password(rainbow_table, hashed_password):
    if hashed_password in rainbow_table:
        return rainbow_table[hashed_password]
    return None

if __name__ == "__main__":
    rainbow_table = load_rainbow_table("rainbow_table.csv")
    
    hashed_password_to_find = input("Entrez le mot de passe clair que vous souhaitez rechercher : ")
    
    password_found = find_password(rainbow_table, hashed_password_to_find)
    
    if password_found is not None:
        print(f"Mot de passe haché trouvé : {password_found}")
    else:
        print("Mot de passe non trouvé dans la rainbow table.")
