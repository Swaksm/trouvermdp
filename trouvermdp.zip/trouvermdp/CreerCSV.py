import hashlib
import csv
import random
import string

def generate_random_password(length):
    characters = string.ascii_letters + string.digits + string.punctuation
    return ''.join(random.choice(characters) for _ in range(length))

def generate_rainbow_table(filename, password_length, max_chain_length):
    rainbow_table = []
    
    for i in range(max_chain_length):
        password = generate_random_password(password_length)
        hash_value = hashlib.md5(password.encode()).hexdigest()
        rainbow_table.append((password, hash_value))

    with open(filename, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerows(rainbow_table)

if __name__ == "__main__":
    generate_rainbow_table("rainbow_table.csv", password_length=5, max_chain_length=1000000)
